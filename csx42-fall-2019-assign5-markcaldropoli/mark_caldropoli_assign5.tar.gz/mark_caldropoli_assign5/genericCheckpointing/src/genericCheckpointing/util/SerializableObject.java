package genericCheckpointing.util;

/**
 * SerializableObject Empty Base Class
 * @author Mark Caldropoli
 */
public class SerializableObject { }
