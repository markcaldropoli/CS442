package genericCheckpointing.server;

/**
 * StoreRestoreI Tag Interface
 * @author Mark Caldropoli
 */
public interface StoreRestoreI { }
