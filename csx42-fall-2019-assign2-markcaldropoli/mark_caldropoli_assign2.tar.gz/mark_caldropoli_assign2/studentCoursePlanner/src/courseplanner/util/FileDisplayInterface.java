package courseplanner.util;

/**
 * Interface for writing output to a file.
 * @author Mark Caldropoli
 */
public interface FileDisplayInterface {
    public void writeToFile();
}
