package loadbalancer.subject;

/**
 * Data Interface
 * @author Mark Caldropoli
 */
public interface Data { }
